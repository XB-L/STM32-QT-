#ifndef MENU_H
#define MENU_H

#include <QWidget>
#include <QProgressBar>
#include "mcu_data.h"
namespace Ui {
class Menu;
}

class Menu : public QWidget
{
    Q_OBJECT

public:
    explicit Menu(QWidget *parent = 0);
    Ui::Menu *ui;
    ~Menu();
    void SetMCUData(PDataFromMCU data);
    PDataToMCU GetQTData();
private slots:
    void on_YaoKong_clicked();

    void on_GenSui_clicked();

    void on_XunXian_clicked();

    void on_GoForward_clicked();

    void on_GoRight_clicked();

    void on_GoBack_clicked();

    void on_GoLeft_clicked();

    void on_TurnLeft_clicked();

    void on_TurnRight_clicked();

    void on_FollowDtcSeekbar_valueChanged(int value);

    void on_FollowDtcSeekbar_sliderReleased();
private:
    PDataToMCU DataT = new DataToMCU;
};

#endif // MENU_H
