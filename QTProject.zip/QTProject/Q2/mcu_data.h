#ifndef MCU_DATA_H
#define MCU_DATA_H


typedef struct DataFromMCU
{
    int MotorLeftFront;
    int MotorRightFront;
    int MotorLeftBack;
    int MotorRightBack;
    int RealTimeDtc;
    int TrackLine1;
    int TrackLine2;
    int TrackLine3;
    int TrackLine4;
}DataFromMCU,*PDataFromMCU;


typedef struct DataToMCU
{
    int CtlFlag;//1 遥控，2跟随，3循迹  a
    int GoFlag;//1 前进， 2右移， 3后退，4左移，5左转，6右转  b
    int SeekBar;//超声波跟随距离 c
}DataToMCU,*PDataToMCU;

void InitDataFromMCU(PDataFromMCU p);
void InitDataToMCU(PDataToMCU p);
#endif // MCU_DATA_H
