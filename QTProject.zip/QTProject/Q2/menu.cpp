#include "menu.h"
#include "ui_menu.h"
#include <QDebug>
Menu::Menu(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Menu)
{
    ui->setupUi(this);
    InitDataToMCU(DataT);
}

Menu::~Menu()
{
    delete ui;
}

void Menu::on_YaoKong_clicked()
{
    DataT->CtlFlag = 1;
    qDebug("遥控模式开\n");
    this->ui->YaoKong->setText("遥控模式开");
    this->ui->GenSui->setText("跟随模式");
    this->ui->XunXian->setText("循线模式");
}


void Menu::on_GenSui_clicked()
{
   DataT->CtlFlag = 2;
    qDebug("跟随模式开\n");
    this->ui->YaoKong->setText("遥控模式");
    this->ui->GenSui->setText("跟随模式开");
    this->ui->XunXian->setText("循线模式");
}

void Menu::on_XunXian_clicked()
{
    DataT->CtlFlag = 3;
    qDebug("循线模式开\n");
    this->ui->YaoKong->setText("遥控模式");
    this->ui->GenSui->setText("跟随模式");
    this->ui->XunXian->setText("循线模式开");
}

void Menu::on_GoForward_clicked()
{
    DataT->GoFlag = 1;
    qDebug("GoFlag = %d\n",DataT->GoFlag);
}

void Menu::on_GoRight_clicked()
{
    DataT->GoFlag = 2;
    qDebug("GoFlag = %d\n",DataT->GoFlag);
}

void Menu::on_GoBack_clicked()
{
    DataT->GoFlag = 3;
    qDebug("GoFlag = %d\n",DataT->GoFlag);
}

void Menu::on_GoLeft_clicked()
{
    DataT->GoFlag = 4;
    qDebug("GoFlag = %d\n",DataT->GoFlag);
}

void Menu::on_TurnLeft_clicked()
{
    DataT->GoFlag = 5;
    qDebug("GoFlag = %d\n",DataT->GoFlag);
}

void Menu::on_TurnRight_clicked()
{
    DataT->GoFlag = 6;
    qDebug("GoFlag = %d\n",DataT->GoFlag);
}


void Menu::on_FollowDtcSeekbar_valueChanged(int value)
{

}

void Menu::on_FollowDtcSeekbar_sliderReleased()
{
    DataT->SeekBar = this->ui->FollowDtcSeekbar->value();
    qDebug("SeekBar = %d\n",DataT->SeekBar);
    this->ui->FollowDtc->setNum(DataT->SeekBar);
}

PDataToMCU Menu::GetQTData()
{
    return DataT;
}

void Menu::SetMCUData(PDataFromMCU data)
{
    ui->MotorLeftBack->setValue(data->MotorLeftBack);
    ui->MotorLeftFront->setValue(data->MotorLeftFront);
    ui->MotorRightBack->setValue(data->MotorRightBack);
    ui->MotorRightFront->setValue(data->MotorRightFront);
    ui->RealTimeDtc->setPlainText(QString::number(data->RealTimeDtc));

    if(data->TrackLine1) ui->TrackLine1->setChecked(true);
    if(data->TrackLine2) ui->TrackLine2->setChecked(true);
    if(data->TrackLine3) ui->TrackLine3->setChecked(true);
    if(data->TrackLine4) ui->TrackLine4->setChecked(true);
}

