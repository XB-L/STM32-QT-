#include "widget.h"
#include "ui_widget.h"
#include <QtSerialPort/QSerialPortInfo>
#include <QDebug>
#include <QMessageBox>
#include <QCoreApplication>
#include <QString>
#include <QJsonDocument>
#include <QJsonObject>
#include <QTimer>
Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    QStringList serialNamePort;
    serilaPort = new QSerialPort(this);
   // InitDataFromMCU(Data);
    connect(serilaPort,SIGNAL(readyRead()),this,SLOT(serilaPortReadyRead_Slot()));
    foreach (const QSerialPortInfo &info ,QSerialPortInfo::availablePorts()) {
        serialNamePort<<info.portName();
    }
    ui->seialCb->addItems(serialNamePort);
}

Widget::~Widget()
{
    delete ui;
}

void Widget::serilaPortReadyRead_Slot()
{
   QString buf;
   buf = QString(serilaPort->readAll());
   qDebug()<<buf;
   GetDataFromMCU(buf);
}
// str = "{ \"name\": \"John\", \"age\": 30, \"city\": \"New York\" }";
// str =  "{ \"MotorLeftFront\": 30, \"MotorRightFront\": 30, \"MotorLeftBack\": 30, \"MotorRightBack\": 30, \"RealTimeDtc\": 30, \"TrackLine1\": true, \"TrackLine2\": true, \"TrackLine3\": true, \"TrackLine4\": true}";
void Widget::GetDataFromMCU(QString str)
{
    QJsonDocument jsonDoc = QJsonDocument::fromJson(str.toUtf8());
    if (!jsonDoc.isNull()) {
        if (jsonDoc.isObject()) {
            QJsonObject jsonObj = jsonDoc.object();
            Data->MotorLeftBack = jsonObj["a"].toInt();
            Data->MotorLeftFront = jsonObj["b"].toInt();
            Data->MotorRightBack = jsonObj["c"].toInt();
            Data->MotorRightFront = jsonObj["d"].toInt();
            Data->RealTimeDtc = jsonObj["e"].toInt();
            Data->TrackLine1 = jsonObj["f"].toInt();
            Data->TrackLine2 = jsonObj["g"].toInt();
            Data->TrackLine3 = jsonObj["h"].toInt();
            Data->TrackLine4 = jsonObj["i"].toInt();
            qDebug() << "MotorLeftBack:" << Data->MotorLeftBack;
            qDebug() << "MotorLeftFront:" << Data->MotorLeftFront;
            qDebug() << "MotorRightBack:" << Data->MotorRightBack;
            qDebug() << "MotorRightFront:" << Data->MotorRightFront;
            qDebug() << "RealTimeDtc:" << Data->RealTimeDtc;
            qDebug() << "TrackLine1:" << Data->TrackLine1;
            qDebug() << "TrackLine2:" << Data->TrackLine2;
            qDebug() << "TrackLine3:" << Data->TrackLine3;
            qDebug() << "TrackLine4:" << Data->TrackLine4;
        } else {
            qDebug() << "JSON document is not an object.";
        }
    } else {
        qDebug() << "Failed to parse JSON.";
    }
    m->SetMCUData(Data);
}




void Widget::on_pushButton_clicked()
{
        QSerialPort::BaudRate baudRate;
        QSerialPort::DataBits dataBits;
        QSerialPort::StopBits stopBits;
        QSerialPort::Parity checkBits;

        if(ui->baundrate->currentText() == "4800"){
            baudRate = QSerialPort::Baud4800;
        }else if(ui->baundrate->currentText() == "9600"){
             baudRate = QSerialPort::Baud9600;
        }else if(ui->baundrate->currentText() == "115200"){
             baudRate = QSerialPort::Baud115200;
        }

        if(ui->data->currentText() == "5"){
            dataBits = QSerialPort::Data5;
        }else if(ui->data->currentText() == "6"){
            dataBits = QSerialPort::Data6;
        }else if(ui->data->currentText() == "7"){
            dataBits = QSerialPort::Data7;
        }else if(ui->data->currentText() == "8"){
            dataBits = QSerialPort::Data8;
        }

        if(ui->stop->currentText() == "1"){
           stopBits = QSerialPort::OneStop;
        }else if(ui->stop->currentText() == "1.5"){
           stopBits = QSerialPort::OneAndHalfStop;
        }else if(ui->stop->currentText() == "2"){
           stopBits = QSerialPort::TwoStop;
        }

        if(ui->check->currentText() == "none"){
            checkBits = QSerialPort::NoParity;
        }

        serilaPort->setPortName(ui->seialCb->currentText());
        serilaPort->setBaudRate(baudRate);
        serilaPort->setDataBits(dataBits);
        serilaPort->setStopBits(stopBits);
        serilaPort->setParity(checkBits);

        if(serilaPort->open(QIODevice::ReadWrite) == true){
            QMessageBox::information(this,"提示","成功");
            m->setGeometry(this->geometry());
            m->show();
           // SendDataToMCU();
        }else{
            QMessageBox::critical(this,"提示","失败");
        }
}

void Widget::SendDataToMCU()
{
    static int cnt = 0;
    PDataToMCU data = new DataToMCU;
    data = m->GetQTData();

    // 创建一个定时器
    QTimer *timer = new QTimer(this);

    connect(timer, &QTimer::timeout, this, [this, data]() {
        // 将数据转换为 JSON 格式
        QJsonObject jsonObj;
        jsonObj["a"] = data->CtlFlag;
        jsonObj["b"] = data->GoFlag;
        jsonObj["c"] = data->SeekBar;

        QJsonDocument jsonDoc(jsonObj);
        QString jsonString = jsonDoc.toJson(QJsonDocument::Compact);
        jsonString.append('\n'); // 添加换行符
        qDebug()<<jsonString<<endl;
        // 向串口发送数据
        if (serilaPort->isOpen()) {
            serilaPort->write(jsonString.toUtf8());
        } else {
            qDebug() << "Serial port is not open.";
        }
    });
    timer->start(100);
}






void Widget::on_closeBt_2_clicked()
{
    serilaPort->close();

}



