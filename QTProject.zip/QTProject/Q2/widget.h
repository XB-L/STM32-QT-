#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QSerialPort>
#include <Qstring>
#include "menu.h"
#include "mcu_data.h"
namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    Menu *m = new Menu;
    ~Widget();
    QSerialPort *serilaPort;


    PDataFromMCU Data = new DataFromMCU;

private slots:
    void on_pushButton_clicked();
    void serilaPortReadyRead_Slot();
    void on_closeBt_2_clicked();

private:
    Ui::Widget *ui;
    void GetDataFromMCU(QString str);
    void SendDataToMCU();
};

#endif // WIDGET_H
