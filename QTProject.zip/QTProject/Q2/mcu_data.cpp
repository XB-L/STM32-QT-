#include "mcu_data.h"

void InitDataFromMCU(PDataFromMCU p)
{
    p->MotorLeftBack = 0;
    p->MotorLeftFront = 0;
    p->MotorRightBack = 0;
    p->MotorRightFront = 0;
    p->RealTimeDtc = 0;
    p->TrackLine1 = 0;
    p->TrackLine2 = 0;
    p->TrackLine3 = 0;
    p->TrackLine4 = 0;
}
void InitDataToMCU(PDataToMCU p)
{
    p->CtlFlag = 0;
    p->GoFlag = 0;
    p->SeekBar = 0;
}
